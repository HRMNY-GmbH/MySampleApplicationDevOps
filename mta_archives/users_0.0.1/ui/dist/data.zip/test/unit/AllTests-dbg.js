sap.ui.define([
	"hrmny/MySampleApplicationDevOps/test/unit/controller/View1.controller"
], function () {
	"use strict";
});